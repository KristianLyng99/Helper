# Helper — Caseworker Web Tool

This is a web tool designed to help caseworkers extract and organize key dates from raw data, such as AAP decisions, Meldekort, and Uføretrygd information. It is built with Next.js and deployable as a static website (e.g., on GitHub Pages).

## Features

- **Paste raw case data** and extract important dates:
  - Sykdato (first sick day)
  - Maks dato (one day before AAP start)
  - AAP start (start of granted AAP)
  - AAP til (last "til" date in AAP section)
  - Uføretrygd fra/til (if present)
- Clean, responsive UI
- No backend required

## Quickstart

### 1. Clone the repository

```sh
git clone https://github.com/KristianLyng99/Helper.git
cd Helper
```

### 2. Install dependencies

```sh
npm install
```

### 3. Run locally

```sh
npm run dev
```

Visit [http://localhost:3000/CaseworkerHelper](http://localhost:3000/CaseworkerHelper)

### 4. Build and Export Static Site

```sh
npm run build
npm run export
```

The static site is generated in the `out/` directory.

### 5. Deploy to GitHub Pages

#### a) Enable GitHub Pages

- Go to your repo settings on GitHub
- In the "Pages" section, choose the `gh-pages` branch (or set it up to deploy from `/out` directory)

#### b) Deploy with `gh-pages` branch (Manual)

```sh
git checkout --orphan gh-pages
git --work-tree out add --all
git --work-tree out commit -m 'Deploy'
git push origin HEAD:gh-pages --force
git checkout main
```

#### c) Or use [github-pages-deploy-action](https://github.com/JamesIves/github-pages-deploy-action) for automatic deployment from CI!

---

## Project Structure

- `src/pages/CaseworkerHelper.tsx` — Main tool UI and logic
- `src/pages/index.tsx` — Simple homepage with link to the tool
- `next.config.js` — Static export configuration for GitHub Pages
- `package.json` — Scripts and dependencies

## Usage

1. Open the tool in your browser.
2. Paste raw case data in the textarea.
3. Click "Trekk ut viktige datoer" to extract and display the important dates.

## License

MIT