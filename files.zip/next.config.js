module.exports = {
  output: "export",
  basePath: "",
  trailingSlash: true,
};